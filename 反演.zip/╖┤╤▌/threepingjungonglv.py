from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import matplotlib.pyplot as plt
import numpy as np
import datetime
import matplotlib.dates as mdates
import os
import obspy
import pandas as pd
from scipy import signal
from tkinter import filedialog, Tk

def calc_avg_power(data_segment, sample_frequency):
    f, Pxx_den = signal.welch(data_segment, sample_frequency, nperseg=256)
    total_power = np.trapz(Pxx_den, f)  # 在频率上积分得到总功率
    avg_power = total_power / len(data_segment)  # 计算平均功率
    return avg_power

def fig_plot(data, ts, te, sample_frequency):
    data = data[ts:te]  # 对数据进行切片

    segment_duration = 60  # 每分钟的样本数量
    segment_length = int(segment_duration * sample_frequency)  # 转换为整数
    avg_powers = []
    for start in range(0, len(data), segment_length):
        end = start + segment_length
        if end > len(data):
            end = len(data)
        segment = data[start:end]
        mean_value = np.nanmean(segment)
        segment = np.where(np.isnan(segment), mean_value, segment)
        avg_power = calc_avg_power(segment, sample_frequency)
        avg_powers.append(avg_power)

    return avg_powers

# 手动选择文件
root = Tk()
root.withdraw()
path = filedialog.askdirectory()  # 选择目录，返回目录名
all_filename = os.listdir(path)  # 保存目录下所有文件名
paths = [os.path.join(path, fn) for fn in all_filename]  # 保存数据文件路径
all_source_name = [fn.split('.')[0] for fn in all_filename]  # 保存数据文件名（去后缀）
print(all_source_name)
fontsize = 12

# 将所有数据合并 SZ4
data_all = [np.full([1863771], np.nan), np.full([1863708], np.nan), np.full([1863730], np.nan)]
components = ['E', 'N', 'Z']
average_powers = {'E': [], 'N': [], 'Z': []}

for i in range(3):
    label = 0
    direction = i  # 选择输出通道方向
    data = data_all[direction]
    for n in range(direction, len(all_filename), 3):
        st = obspy.read(paths[n])  # 读取N通道
        tr = st[0]
        tr_filt = tr.copy()
        tr_filt.filter('bandpass', freqmin=2, freqmax=7, corners=2, zerophase=True)  # 带通滤波
        signal_data = tr_filt.data

        sample_frequency = tr.stats.sampling_rate  # 每秒记录 sample_frequency 个样本(采样频率)
        ts = 0  # 波形中开始的时间 秒（开始样本位置）
        te = tr.stats.npts  # 波形中结束的时间 秒（结束样本位置）
        signal_data = signal_data[ts:te]  # 对数据进行切片
        signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
        data[label:(label + len(signal_data))] = signal_data
        label += len(signal_data)
        if n == 9:
            label += 1320
        elif n == 10:
            label += 1393
        elif n == 11:
            label += 1415
        elif n == 15:
            label += 1411
        elif n == 16:
            label += 1369
        elif n == 17:
            label += 1493
        elif n == 24:
            label += 1354
        elif n == 25:
            label += 1447
        elif n == 26:
            label += 1324
        else:
            label = label

    test_list = [3]
    start_time_list = [[6504.26], [6505.475], [6505.115]]
    end_time_list = [[7704.26], [7705.475], [7705.115]]
    for j in range(1):
        test = test_list[j]
        start_time = start_time_list[i][j]
        end_time = end_time_list[i][j]
        ts = round(start_time * sample_frequency)  # 波形中开始的时间 秒（开始样本位置）
        te = round(end_time * sample_frequency)  # 波形中结束的时间 秒（结束样本位置）
        avg_powers = fig_plot(data, ts, te, sample_frequency)
        average_powers[components[i]].extend(avg_powers)

# 流量数据
t = [datetime.datetime(2024, 3, 17, 15, 50)]
for tm in range(9):
    T = t[tm] + datetime.timedelta(minutes=1)
    t.append(T)

discharge = [0.511, 0.515, 0.512, 0.503, 0.504, 0.511, 0.509, 0.513, 0.516, 0.512]
discharge_mean = np.mean(discharge)
discharge_std = np.std(discharge)

# 确保时间点和平均功率数组长度一致
min_length = min(len(t), len(average_powers['E']), len(average_powers['N']), len(average_powers['Z']))
t = t[:min_length]
discharge = discharge[:min_length]
average_powers['E'] = average_powers['E'][:min_length]
average_powers['N'] = average_powers['N'][:min_length]
average_powers['Z'] = average_powers['Z'][:min_length]

# 绘制图表
fig, ax1 = plt.subplots(figsize=(14, 7))

# 绘制流量
ax1.errorbar(t, discharge, yerr=discharge_std, fmt='-o', color='k', ecolor='k', elinewidth=2, capsize=4, label='Discharge')
ax1.set_xlabel("Time", fontsize=16, fontproperties="Times New Roman")
ax1.set_ylabel("Discharge (m³/s)", fontsize=16, fontproperties="Times New Roman")
ax1.set_ylim(0.45, 0.55)
ax1.set_xlim(t[0], t[-1] + datetime.timedelta(minutes=1))
ax1.tick_params(axis='both', tickdir='in')
plt.xticks(fontsize=16, fontfamily='Times New Roman')
plt.yticks(fontsize=16, fontfamily='Times New Roman')
timeFmt = mdates.DateFormatter('%H:%M')
ax1.xaxis.set_major_formatter(timeFmt)

# 绘制每个通道的平均功率
colors = {'E': '#369F2D', 'N': '#0093E4', 'Z': '#F46E49'}  # 浅绿色、浅粉红色、浅黄色
ax2 = ax1.twinx()
for comp in components:
    avg_powers_mean = np.mean(average_powers[comp])
    avg_powers_std = np.std(average_powers[comp])
    ax2.errorbar(t, average_powers[comp], yerr=avg_powers_std, fmt='-o', color=colors[comp],
                 ecolor=colors[comp], elinewidth=2, capsize=4, label=f'Average Power {comp}')

ax2.set_ylabel("Average Seismic Power (m²/s²)", fontsize=16, fontproperties="Times New Roman")
ax2.tick_params(axis="y", labelsize=16, tickdir='in')
y2_label = ax2.get_yticklabels()
[y2_label_temp.set_fontname('Times New Roman') for y2_label_temp in y2_label]

# 显示图例
fig.legend(loc='upper right', bbox_to_anchor=(1, 1), bbox_transform=ax1.transAxes, fontsize=9, title_fontproperties='Times New Roman')

plt.show()

print('Finish')
