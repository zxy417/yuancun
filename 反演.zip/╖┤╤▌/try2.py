import matplotlib.pyplot as plt

# 流量数据
flow_data = [0.444,0.611, 0.512, 0.598]

# 平均功率数据
power_data = [1.5403311200635335e-09, 2.1121388188995215e-11, 1.9155434182379757e-11, 3.506766317282112e-11]
#改11
# 错误棒（假设一些误差值）
flow_error = [ 0.02,0.03, 0.01, 0.025]  # 这里假设的是流量数据的误差
power_error = [1e-11, 1e-12, 1e-12, 2e-12]  # 这里假设的是平均功率数据的误差
#改12的话整体变化趋势是一致的
# 绘制折线图
fig, ax1 = plt.subplots()

# 绘制流量数据折线
ax1.errorbar(range(1, 5), flow_data, yerr=flow_error, fmt='-o', color='#FFA500', label='Flow Rate (m$^3$/s)')
ax1.set_xlabel('Measurement')
ax1.set_ylabel('Flow Rate (m$^3$/s)')
ax1.tick_params(axis='y')

# 创建第二个y轴，共享x轴
ax2 = ax1.twinx()
# 绘制平均功率数据折线
ax2.errorbar(range(1, 5), power_data, yerr=power_error, fmt='-o', color='c', label='Average Power (m$^2$/s$^2$)')
ax2.set_ylabel('Average Power (m$^2$/s$^2$)')
ax2.tick_params(axis='y')

# 添加图例
fig.legend(loc='upper right', bbox_to_anchor=(0.85, 0.85))

# 标题
plt.title('Flow Rate and Average Power Data')

# 显示图形
plt.show()
