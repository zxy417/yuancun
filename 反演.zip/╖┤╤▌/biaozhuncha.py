import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 三次实验的真实值和预测值
true_values = [0.444, 0.611, 0.589]
predicted_values_list = [
    [0.494, 0.466, 0.444, 0.484, 0.451, 0.388, 0.492, 0.497, 0.438, 0.416, 0.427],
    [0.472, 0.481, 0.459, 0.602, 0.481, 0.571, 0.667, 0.448, 0.614, 0.589, 0.648],
    [0.49, 1.05, 0.676, 0.888, 0.598, 0.408, 0.37, 0.757, 0.248, 0.169, 0.267]
]

# 计算平均绝对误差
mae_list = [np.mean(np.abs(np.array(predicted_values) - true_value))
            for true_value, predicted_values in zip(true_values, predicted_values_list)]

# 打印平均绝对误差
for i, mae in enumerate(mae_list):
    print(f'MAE{i+1}: {mae:.6f} m³/s')

# 创建三维绘图
fig = plt.figure(figsize=(10, 6))
ax = fig.add_subplot(111, projection='3d')

# 设置颜色
colors = ['#ADD8E6', '#FFB6C1', '#90EE90']  # 浅蓝色、浅红色、浅绿色

# 散点图
y_positions = [1, 2, 4]  # 实验的Y坐标位置
for i, (predicted_values, true_value, mae) in enumerate(zip(predicted_values_list, true_values, mae_list)):
    x = np.arange(1, len(predicted_values) + 1)
    y = np.full_like(x, y_positions[i])
    z = np.array(predicted_values)
    ax.scatter(x, y, z, color=colors[i], label=f'Qpre{i+1}')
    ax.plot([0, 10], [y_positions[i], y_positions[i]], [true_value, true_value], color=colors[i], linestyle='-', label=f'Qobs{i+1}: {true_value:.6f} m³/s')
    ax.text(10, y_positions[i], true_value, f'MAE{i+1}: {mae:.6f} m³/s', horizontalalignment='right')

# 设置标签和标题


ax.set_zlabel('Discharge (m³/s)')

# 设置坐标范围
ax.set_xlim(0, 10)
ax.set_zlim(0, 1.5)
# 设置y坐标标签
ax.set_yticks([1, 2, 3])
ax.set_yticklabels(['Experiment1', 'Experiment2', 'Experiment4'])
# 去掉网格线
ax.grid(False)

# 显示图例
legend = ax.legend(loc='upper left', fontsize='small', markerscale=0.7)
for label in legend.get_texts():
    label.set_fontsize('small')
for label in (ax.get_xticklabels() + ax.get_yticklabels() + ax.get_zticklabels()):
    label.set_fontsize('medium')

# 显示图形
plt.show()
