import numpy as np
import matplotlib.pyplot as plt

# 实验数据
measured_values = [0.444, 0.611, 0.589]
predicted_values = [
    [0.494, 0.466, 0.444, 0.484, 0.451, 0.388, 0.492, 0.497, 0.438, 0.416, 0.427],
    [0.472, 0.481, 0.459, 0.602, 0.481, 0.571, 0.667, 0.448, 0.614, 0.589, 0.648],
    [0.49, 1.05, 0.676, 0.888, 0.598, 0.408, 0.37, 0.757, 0.248, 0.169, 0.267]
]

# 计算每次实验的预测值平均值和标准差
average_predicted = [np.mean(predictions) for predictions in predicted_values]
std_predicted = [np.std(predictions) for predictions in predicted_values]

# 设置图表
fig, ax = plt.subplots()

# 绘制实测值
ax.scatter(range(1, 4), measured_values, color='#90EE90', label='Q$_o$$_b$$_s$')

# 绘制预测值平均值及其误差棒
ax.errorbar(range(1, 4), average_predicted, yerr=std_predicted, fmt='o', color='pink',
            ecolor='pink', elinewidth=1, capsize=5, capthick=1, label='Q$_p$$_r$$_e$')


# 设置横坐标标签
ax.set_xticks([1, 2, 3])
ax.set_xticklabels(['Test1', 'Test2', 'Test4'])

# 设置轴标签和图例

ax.set_ylabel('Discharge(m³/s)')
ax.legend()

# 显示图表
plt.show()
