import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from scipy import stats

def rsquared(x, y):
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
    #a、b、r
    print("使用scipy库：a：",slope,"b：", intercept,"r：", r_value,"r-squared：", r_value**2)


# 拟合数据
x = np.array([0.511,0.515,0.512,0.503,0.504,0.511,0.509,0.513,0.516,0.512]).reshape(-1,1)
y = np.array([3.5340344169505284e-06,
 3.547986485321299e-06,
 3.0661016250806147e-06,
 3.2458302363001024e-06,
 3.419761277354186e-06,
 3.4394037413024246e-06,
 3.3372392390866753e-06,
 3.8228463023245785e-06,
 3.832438970308048e-06,
 3.2226491196126884e-06])

# 创建线性回归模型对象
model  = LinearRegression()

# 使用数据拟合模型
model.fit(x,y)

# 打印参数
print('斜率：',model.coef_[0])
print('截距：',model.intercept_)

# 绘制数据和拟合直线
fig1 = plt.figure(figsize=(10, 8))
ax1 = fig1.add_subplot(1, 1, 1)
ax1.scatter(x,y,color='b',label='Discharge data')
ax1.plot(x,model.predict(x),'r',label='Linear regression')
ax1.set_xlabel('Discharge(m³/s)',fontsize=18, fontproperties="Times New Roman")
ax1.set_ylabel('10*log10(m$^2$/s$^2$/Hz),[dB]',fontsize=18, fontproperties="Times New Roman")
ax1.tick_params(axis='both', tickdir='in')
plt.xticks(fontsize=15, fontfamily='Times New Roman')
plt.yticks(fontsize=15, fontfamily='Times New Roman')
plt.legend(fontsize=14, title_fontproperties='Times New Roman')
plt.show()

#fig1.savefig(r'C:\Users\小哲\Desktop\three_channel.tiff', dpi=300)

X = [0.511,0.515,0.512,0.503,0.504,0.511,0.509,0.513,0.516,0.512]
Y = [3.5340344169505284e-06,
 3.547986485321299e-06,
 3.0661016250806147e-06,
 3.2458302363001024e-06,
 3.419761277354186e-06,
 3.4394037413024246e-06,
 3.3372392390866753e-06,
 3.8228463023245785e-06,
 3.832438970308048e-06,
 3.2226491196126884e-06]
rsquared(X, Y)