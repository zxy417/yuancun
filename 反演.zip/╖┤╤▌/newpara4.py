from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import obspy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os.path
from obspy.signal.filter import envelope
from scipy.fft import rfftfreq, rfft
import matplotlib as mpl
from scipy import signal
import datetime
import matplotlib.dates as mdates

def inverse_calculate_nf_pvf(data, ts, te, sample_frequency):
    data = np.transpose(data[ts:te])  # 对数据进行切片并转置
    data = np.array(data).squeeze()
    data = data[~np.isnan(data)]  # 去除nan值

    """计算nf"""
    nf_ts = 460 * sample_frequency
    nf_te = 560 * sample_frequency
    f, Pxx_Nf = signal.welch(data[nf_ts:nf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')
    Nf = Pxx_Nf

    """计算vf"""
    vf_ts_list = [753,970,1005,1089,1112]
    vf_te_list = [776,986,1017,1104,1123]
    Pvf_list = []
    for k in range(5):
        vf_ts = vf_ts_list[k] * sample_frequency
        vf_te = vf_te_list[k] * sample_frequency
        f, Pxx_vf = signal.welch(data[vf_ts:vf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')
        Pvf_list.append(Pxx_vf)
    Pvf = Pvf_list[0] + Pvf_list[1] + Pvf_list[2] + Pvf_list[3] + Pvf_list[4]

    return Nf,Pvf

"""手动选择文件"""
import tkinter as tk
from tkinter import filedialog
root = tk.Tk()
root.withdraw()
path = filedialog.askdirectory()  # 选择目录，返回目录名
all_filename = os.listdir(path)  # 保存目录下所有文件名
paths = []                       # 空列表，保存数据文件路径
for n in range(len(all_filename)):
    a = os.path.join(path,all_filename[n])
    paths.append(a)
all_source_name = []             #空列表，保存数据文件名（去后缀）
for n in range(len(all_filename)):
    filename = all_filename[n].split('.')[0]
    all_source_name.append(filename)
print(all_source_name)


"""将所有数据合并，计算三个通道Nf、Pvf   SZ3  位置1"""
Nf_three = []
Pvf_three = []
data_all = [np.full([1318203], np.nan),np.full([1318198], np.nan),np.full([1318267], np.nan)]
components = ['E', 'N', 'Z']
for i in range(0,3,1):
    label = 0
    direction = i  # 选择输出通道方向
    data = data_all[direction]
    for n in range(direction, len(all_filename), 3):
        st = obspy.read(paths[n])  # 读取N通道
        if n == 6 or n == 7 or n == 8 or n == 9 or n == 10 or n == 11 or n == 15 or n == 16 or n == 17:
            tr = [st[0], st[1]]
        else:
            tr = st[0]
        """滤波"""
        if n == 6 or n == 7 or n == 8 or n == 9 or n == 10 or n == 11 or n == 15 or n == 16 or n == 17:
            tr_filt = [tr[0].copy(),tr[1].copy()]
            # tr_filt.filter('bandpass', freqmin=1, freqmax=10, corners=2, zerophase=True)  # 带通滤波
            # tr_filt.filter('lowpass', freq=10.0, corners=2, zerophase=True)  # # 低通滤波
            tr_filt = [tr_filt[0].filter('highpass', freq=1, corners=2, zerophase=True),
                     tr_filt[1].filter('highpass', freq=1, corners=2, zerophase=True)]# 高通滤波
            signal_data = [tr_filt[0].data,tr_filt[1].data]
            signal_data = [(((signal_data[0] * 1.19209289550781E-07) / 80) * 1000),
                           (((signal_data[1] * 1.19209289550781E-07) / 80) * 1000)]  # 电信号转为速度信号  # 转存微震时间序列 m/s
            data[label:(label + len(signal_data[0]))] = signal_data[0]
            label += len(signal_data[0])
            if n == 6:
                label += 1425
            elif n == 7:
                label += 1337
            elif n == 8:
                label += 1297
            elif n == 9:
                label += 1509
            elif n == 10:
                label += 1331
            elif n == 11:
                label += 1507
            elif n == 15:
                label += 1475
            elif n == 16:
                label += 1154
            elif n == 17:
                label += 1304
            else:
                label = label
            data[label:(label + len(signal_data[1]))] = signal_data[1]
            label += len(signal_data[1])
        else:
            tr_filt = tr.copy()
            tr_filt.filter('highpass', freq=1, corners=2, zerophase=True)  # 高通滤波
            signal_data = tr_filt.data
            signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
            data[label:(label + len(signal_data))] = signal_data
            label += len(signal_data)


        """不滤波"""
        # if n == 6 or n == 7 or n == 8 or n == 9 or n == 10 or n == 11 or n == 15 or n == 16 or n == 17:
        #     signal_data = [st.traces[0].data, st.traces[1].data]
        #     signal_data = [(((signal_data[0] * 1.19209289550781E-07) / 80) * 1000),
        #                    (((signal_data[1] * 1.19209289550781E-07) / 80) * 1000)]  # 电信号转为速度信号  # 转存微震时间序列 m/s
        #     data[label:(label + len(signal_data[0]))] = signal_data[0]
        #     label += len(signal_data[0])
        #     if n == 6:
        #         label += 1425
        #     elif n == 7:
        #         label += 1337
        #     elif n == 8:
        #         label += 1297
        #     elif n == 9:
        #         label += 1509
        #     elif n == 10:
        #         label += 1331
        #     elif n == 11:
        #         label += 1507
        #     elif n == 15:
        #         label += 1475
        #     elif n == 16:
        #         label += 1154
        #     elif n == 17:
        #         label += 1304
        #     else:
        #         label = label
        #     data[label:(label + len(signal_data[1]))] = signal_data[1]
        #     label += len(signal_data[1])
        # else:
        #     signal_data = st.traces[0].data
        #     signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
        #     data[label:(label + len(signal_data))] = signal_data
        #     label += len(signal_data)

    """calculate"""
    sample_frequency = 200
    start_time_list = [[5339.325], [5340.33],[5339.78]]
    end_time_list = [[6539.325], [6540.33],[6539.78]]
    for j in range(0,1):
        start_time = start_time_list[i][j]
        end_time = end_time_list[i][j]
        ts = round(start_time * sample_frequency)  # 波形中开始的时间 秒（开始样本位置）
        te = round(end_time * sample_frequency)  # 波形中结束的时间 秒（结束样本位置）
        Nf,Pvf = inverse_calculate_nf_pvf(data, ts, te, sample_frequency)
        Nf_three.append(Nf)
        Pvf_three.append(Pvf)

N = pd.DataFrame(np.transpose(Nf_three), columns=['E_Nf','N_Nf','Z_Nf'])
V = pd.DataFrame(np.transpose(Pvf_three), columns=['E_Pvf','N_Pvf','Z_Pvf'])
para_nf_vf = pd.concat([N,V],axis=1)

para_nf_vf.to_csv(r'D:\ZhouXiaoQi\biyederuanjian\小论文代码\代码\反演\nf_vf_para_1_pre1.csv', index=False)  # 保存文件

print('Finish')
