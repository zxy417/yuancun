from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import obspy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os.path
from obspy.signal.filter import envelope
from scipy.fft import rfftfreq, rfft
import matplotlib as mpl
from scipy import signal
import datetime
import matplotlib.dates as mdates


def fig_plot(data, ts, te, sample_frequency):
    data = np.transpose(data[ts:te])  # 对数据进行切片并转置
    data = np.array(data).squeeze()

    # Generate time series for the data points
    t_test = [datetime.datetime(2024, 3, 17, 11, 50)]
    for tm in range(len(data) - 1):
        T = t_test[tm] + datetime.timedelta(seconds=1 / sample_frequency)
        t_test.append(T)

    # 计算开始和结束时间
    start_time = t_test[0]
    end_time = t_test[-1]

    """绘制波形图"""
    fig1 = plt.figure(figsize=(5, 3.6))  # 绘制波形图(单图)
    ax1 = fig1.add_subplot(1, 1, 1)
    ax1.plot(np.linspace(0, len(data) / sample_frequency, len(data)), data, 'k', linewidth=0.5)
    ax1.set_xlabel("Time (s)", fontsize=12, fontproperties="Times New Roman")
    ax1.set_ylabel("Velocity (m/s)", fontsize=12, fontproperties="Times New Roman")
    ax = plt.gca()
    ax.yaxis.get_major_formatter().set_powerlimits((0, 1))  # 坐标的科学记数法表示
    ax1.set_xlim(0, len(data) / sample_frequency)
    ax1.tick_params(axis='both', tickdir='in')
    plt.xticks(fontsize=12, fontfamily='Times New Roman')
    plt.yticks(fontsize=12, fontfamily='Times New Roman')

    """绘制频谱图"""
    Fs = sample_frequency
    NFFT = 200  # FFT中每个片段的数据点数（窗长度)
    noverlap = int(NFFT * 1 / 2)  # 窗之间的重叠长度
    fig2 = plt.figure(figsize=(7, 9))
    ax1 = fig2.add_subplot(3, 1, 1)
    Pxx, freqs, bins, imm = ax1.specgram(data, mode='psd', scale='dB', detrend='linear', NFFT=NFFT, Fs=Fs,
                                         noverlap=noverlap,
                                         cmap=plt.get_cmap('jet'), vmin=-80, vmax=-40)
    axins = inset_axes(ax1, width="1.5%", height="100%", borderpad=-1, loc='right')  # 设置颜色条位置
    locator = mpl.ticker.MultipleLocator(100)
    cb = fig2.colorbar(imm, cax=axins, orientation='vertical', ticklocation='right', ticks=locator)
    cb.set_label(label='10*log10(m$^2$/s$^2$/Hz),[dB]', fontsize=12, fontproperties="Times New Roman")
    cb.ax.tick_params(labelsize=12)
    cb.update_ticks()
    ax1.set_ylabel("Frequency (Hz)", fontsize=12, fontproperties="Times New Roman")
    ax1.set_xlabel("Time (s)", fontsize=12, fontproperties="Times New Roman")

    """FFT（快速傅里叶变换）"""
    y = data  # 不滤波
    yf = abs(rfft(y, n=len(y)))
    yfreq = rfftfreq(n=len(y), d=1 / sample_frequency)
    ax2 = fig2.add_subplot(3, 1, 2)
    plt.plot(yfreq, yf, color='k', linewidth=0.5)
    plt.xlim(yfreq.min(), yfreq.max())
    ax2.yaxis.get_major_formatter().set_powerlimits((0, 1))
    ax2.tick_params(axis='both', tickdir='in')
    plt.xticks(fontsize=12, fontfamily='Times New Roman')
    plt.yticks(fontsize=12, fontfamily='Times New Roman')
    ax2.set_ylabel("FFTA", fontsize=12, fontproperties="Times New Roman")
    ax2.set_xlabel("Frequency (Hz)", fontsize=12, fontproperties="Times New Roman")

    """使用 Welch 方法估计功率谱密度"""
    ax3 = fig2.add_subplot(3, 1, 3)
    f, Pxx_den = signal.welch(data, Fs, nperseg=200, noverlap=100, scaling='density')
    ax3.plot(f, 10 * np.log10(Pxx_den), 'k')
    ax3.tick_params(axis='both', tickdir='in')
    plt.xticks(fontsize=12, fontfamily='Times New Roman')
    plt.yticks(fontsize=12, fontfamily='Times New Roman')
    plt.xlim(f.min(), f.max())
    ax3.set_ylabel("PSD [10*log10(m$^2$/s$^2$/Hz)]", fontsize=12, fontproperties="Times New Roman")
    ax3.set_xlabel("Frequency (Hz)", fontsize=12, fontproperties="Times New Roman")
    plt.subplots_adjust(hspace=0.5)

    plt.show()
    plt.close('all')


###################################主程序####################################
"""手动选择文件"""
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()
path = filedialog.askdirectory()  # 选择目录，返回目录名
all_filename = os.listdir(path)  # 保存目录下所有文件名
paths = []  # 空列表，保存数据文件路径
for n in range(len(all_filename)):
    a = os.path.join(path, all_filename[n])
    paths.append(a)
all_source_name = []  # 空列表，保存数据文件名（去后缀）
for n in range(len(all_filename)):
    filename = all_filename[n].split('.')[0]
    all_source_name.append(filename)
print(all_source_name)
fontsize = 12

"""将所有数据合并"""
components = ['E', 'N', 'Z']
for i in range(0, 3, 1):
    data = pd.DataFrame()
    direction = i  # 选择输出通道方向
    for n in range(direction, len(all_filename), 3):
        st = obspy.read(paths[n])  # 读取N通道
        tr = st[0]
        """滤波"""
        tr_filt = tr.copy()
        tr_filt.filter('highpass', freq=1, corners=2, zerophase=True)  # 高通滤波
        signal_data = tr_filt.data

        """不滤波"""
        # signal_data = st.traces[0].data

        sample_frequency = tr.stats.sampling_rate  # 每秒记录 sample_frequency 个样本(采样频率)
        ts = 0  # 波形中开始的时间 秒（开始样本位置）
        te = tr.stats.npts  # 波形中结束的时间 秒（结束样本位置）
        signal_data = signal_data[ts:te]  # 对数据进行切片
        signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
        df = pd.DataFrame(np.array(signal_data))
        data = pd.concat([data, df], axis=0, ignore_index=True)
    """plot"""
    test_list = [2, 4, 3]
    start_time_list = [[2754, 4353.36, 6073.865], [2754, 4354, 6073.985], [2754, 4354.05, 6075.1]]
    end_time_list = [[3954, 5553.36, 7273.865], [3954, 5554, 7273.985], [3954, 5554.05, 7275.1]]
    for j in range(0, 3, 1):
        test = test_list[j]
        start_time = start_time_list[i][j]
        end_time = end_time_list[i][j]
        midpoint = (start_time + end_time) / 2
        start_time = midpoint - 60  # Start time is one minute before midpoint
        end_time = midpoint + 60  # End time is one minute after midpoint
        ts = round(start_time * sample_frequency)  # 波形中开始的时间 秒（开始样本位置）
        te = round(end_time * sample_frequency)  # 波形中结束的时间 秒（结束样本位置）
        fig_plot(data, ts, te, sample_frequency)

print('Finish')
