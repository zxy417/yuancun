###############################引用数据库与函数##############################
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import obspy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os.path
from obspy.signal.filter import envelope
from scipy.fft import rfftfreq, rfft
import matplotlib as mpl
from scipy import signal
import datetime
import matplotlib.dates as mdates

def fig_plot(data, ts, te,sample_frequency):
    data = data[ts:te]  # 对数据进行切片
    t = [datetime.datetime(2024, 3, 17, 11, 50), datetime.datetime(2024, 3, 17, 13, 20),datetime.datetime(2024, 3, 17, 15, 50),datetime.datetime(2024, 3, 17, 17, 20)]
    t_test = [t[j]]
    for tm in range(len(data) - 1):
        T = t_test[tm] + datetime.timedelta(seconds=0.005)
        t_test.append(T)
    # print(t_test)


    """绘制波形图"""
    fig1 = plt.figure(figsize=(13, 3.6))  # 绘制波s形图(单图)
    ax1 = fig1.add_subplot(1, 1, 1)
    ax1.plot(t_test, data, 'k', linewidth=0.5)
    ax1.set_xlabel("Time", fontsize=12, fontproperties="Times New Roman")
    ax1.set_ylabel("Velocity (m/s)", fontsize=12, fontproperties="Times New Roman")
    ax = plt.gca()
    ax.yaxis.get_major_formatter().set_powerlimits((0, 1))  # 坐标的科学记数法表示
    # plt.ylim(datas.min(), datas.max())
    ax1.set_xlim(t_test[0], t_test[len(data) - 1] + datetime.timedelta(seconds=0.005))
    ax1.tick_params(axis='both', tickdir='in')
    plt.xticks(fontsize=12, fontfamily='Times New Roman')
    plt.yticks(fontsize=12, fontfamily='Times New Roman')
    timeFmt = mdates.DateFormatter('%H:%M')
    ax.xaxis.set_major_formatter(timeFmt)
    plt.show()
    plt.close(fig1)  # Close the figure
    #fig1.savefig(r'C:\Users\小哲\Desktop\three_channel.tiff', dpi=300)
    # fig1.savefig(r'D:\PycharmProject\UndergraduateGraduation\paper_new\paper_picture\test_%s\S5\wave.SZ.%s.tiff' % (test,components[direction]),dpi=300, bbox_inches='tight')  # 保存为tif图像文件

    """绘制频谱图"""
    Fs = sample_frequency
    NFFT = 200  # FFT中每个片段的数据点数（窗长度)
    noverlap = int(NFFT * 1 / 2)  # 窗之间的重叠长度
    fig2 = plt.figure(figsize=(13, 8))
    ax1 = fig2.add_subplot(3, 1, 1)
    Pxx, freqs, bins, imm = ax1.specgram(data, mode='psd', scale='dB',detrend='linear', NFFT=NFFT, Fs=Fs, noverlap=noverlap,
                                         cmap=plt.get_cmap('jet'), vmin=-80, vmax=-40)
    axins = inset_axes(ax1, width="1.5%", height="100%", borderpad=-3, loc='right')  # 设置颜色条位置
    locator = mpl.ticker.MultipleLocator(20)
    cb = fig2.colorbar(imm, cax=axins, orientation='vertical', ticklocation='right', ticks=locator)
    cb.set_label(label='10*log10(m$^2$/s$^2$/Hz)', fontsize=12, fontproperties="Times New Roman")
    cb.ax.tick_params(labelsize=12)
    cb.update_ticks()
    ax1.set_ylabel("Frequency (Hz)", fontsize=12, fontproperties="Times New Roman")
    ax1.set_xlabel("Time", fontsize=12, fontproperties="Times New Roman")
    my_x_ticks = np.arange(0, len(data) / sample_frequency + 300, 300)
    time = np.arange(t_test[0], t_test[len(data) - 1] + datetime.timedelta(minutes=5), datetime.timedelta(minutes=5))
    time = time.astype(datetime.datetime)
    for i in range(len(time)):
        time[i] = time[i].strftime("%H:%M")
    ax1.set_xticks(my_x_ticks, time)
    ax1.tick_params(axis='both', labelsize=10)
    x1_label = ax1.get_xticklabels()
    [x1_label_temp.set_fontname('Times New Roman') for x1_label_temp in x1_label]
    y1_label = ax1.get_yticklabels()
    [y1_label_temp.set_fontname('Times New Roman') for y1_label_temp in y1_label]

    """FFT（快速傅里叶变换）"""
   # data = data[~np.isnan(data)] #去除nan值
    #y = data  # 不滤波
    #yf = abs(rfft(y, n=len(y)))
    #yfreq = rfftfreq(n=len(y), d=1 / sample_frequency)

    #ax2 = fig2.add_subplot(3, 1, 2)
    #plt.plot(yfreq, yf, color='k', linewidth=0.5)
    #plt.xlim(yfreq.min(), yfreq.max())
    #ax2.yaxis.get_major_formatter().set_powerlimits((0, 1))
    #ax2.tick_params(axis='both', tickdir='in')
    #plt.xticks(fontsize=12, fontfamily='Times New Roman')
    #plt.yticks(fontsize=12, fontfamily='Times New Roman')
    #ax2.set_ylabel("FFTA", fontsize=12, fontproperties="Times New Roman")
    #ax2.set_xlabel("Frequency (Hz)", fontsize=12, fontproperties="Times New Roman")

    """使用 Welch 方法估计功率谱密度"""
    #ax3 = fig2.add_subplot(3, 1, 3)
    #f, Pxx_den = signal.welch(data, Fs, nperseg=200, noverlap=100, scaling='density')
    #ax3.plot(f, 10 * np.log10(Pxx_den), 'k')
    #ax3.tick_params(axis='both', tickdir='in')
    #plt.xticks(fontsize=12, fontfamily='Times New Roman')
    #plt.yticks(fontsize=12, fontfamily='Times New Roman')
    # plt.xlim(f.min(), f.max())
    #ax3.set_ylabel("PSD[10*log10(m$^2$/s$^2$/Hz)]", fontsize=12, fontproperties="Times New Roman")
    # ax3.set_xlabel("Frequency(Hz)", fontsize=12, fontproperties="Times New Roman")

    # plt.subplots_adjust(hspace=0.5)
    #fig2.savefig(r'D:\PycharmProject\UndergraduateGraduation\paper_new\paper_picture\test_%s\S5\time-frequency.SZ.%s.tiff' % (
     #   test, components[direction]), dpi=300)  # 保存为tif图像文
plt.show()
plt.close('all') #关闭所有绘图窗口

###################################主程序####################################
"""手动选择文件"""
import tkinter as tk
from tkinter import filedialog
root = tk.Tk()
root.withdraw()
path = filedialog.askdirectory()  # 选择目录，返回目录名
all_filename = os.listdir(path)  # 保存目录下所有文件名
paths = []                       # 空列表，保存数据文件路径
for n in range(len(all_filename)):
    a = os.path.join(path,all_filename[n])
    paths.append(a)
all_source_name = []             #空列表，保存数据文件名（去后缀）
for n in range(len(all_filename)):
    filename = all_filename[n].split('.')[0]
    all_source_name.append(filename)
print(all_source_name)
fontsize = 12

"""将所有数据合并"""
data_all = [np.full([1887502], np.nan),np.full([1887498], np.nan),np.full([1887532], np.nan)]
components = ['E', 'N', 'Z']
for i in range(0,3,1):
    label = 0
    direction = i # 选择输出通道方向
    data = data_all[direction]
    for n in range(direction,len(all_filename),3):
        st = obspy.read(paths[n])       # 读取N通道
        tr = st[0]
        """滤波"""
        tr_filt = tr.copy()
        # tr_filt.filter('bandpass', freqmin=1, freqmax=12, corners=2, zerophase=True)  # 带通滤波
        # tr_filt.filter('lowpass', freq=10.0, corners=2, zerophase=True)  # # 低通滤波
        tr_filt.filter('highpass', freq=1, corners=2, zerophase=True)  # 高通滤波
        signal_data = tr_filt.data

        """不滤波"""
        # signal_data = st.traces[0].data
        sample_frequency = tr.stats.sampling_rate       # 每秒记录 sample_frequency 个样本(采样频率)
        ts = 0        # 波形中开始的时间 秒（开始样本位置）
        te = tr.stats.npts           # 波形中结束的时间 秒（结束样本位置）
        signal_data = signal_data[ts:te]  # 对数据进行切片
        signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
        data[label:(label + len(signal_data))] = signal_data
        label += len(signal_data)
        if n == 9:
            label += 1510
        elif n == 10:
            label += 1494
        elif n == 11:
            label += 1283
        elif n == 24:
            label += 1280
        elif n == 25:
            label += 1487
        elif n == 26:
            label += 1412
        else:
            label = label
    """plot"""
    test_list = [2, 4, 3, 1]
    start_time_list = [[2762.765, 4857.315, 6611.43, 8129.72], [2762.69, 4858.685, 6611.765, 8129.205],[2761.465, 4856.535, 6610.435, 8128.6]]
    end_time_list = [[3962.765, 6057.315, 7811.43, 9329.72], [3962.69, 6058.685, 7811.765, 9329.205], [3961.465, 6056.535, 7810.4355, 9328.6]]
    for j in range(0, 4, 1):
        test = test_list[j]
        start_time = start_time_list[i][j]
        end_time = end_time_list[i][j]
        ts = round(start_time * sample_frequency)  # 波形中开始的时间 秒（开始样本位置）
        te = round(end_time * sample_frequency)  # 波形中结束的时间 秒（结束样本位置）
        fig_plot(data, ts, te, sample_frequency)


print('Finish')