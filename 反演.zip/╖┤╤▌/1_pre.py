from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import obspy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os.path
from obspy.signal.filter import envelope
from scipy.fft import rfftfreq, rfft
import matplotlib as mpl
from scipy import signal
import datetime
import matplotlib.dates as mdates

def inverse_calculate_nf_pvf(data, ts, te, sample_frequency):
    data = np.transpose(data[ts:te])  # 对数据进行切片并转置
    data = np.array(data).squeeze()
    data = data[~np.isnan(data)]  # 去除nan值

    """计算nf"""
    nf_ts = 460 * sample_frequency
    nf_te = 560 * sample_frequency
    f, Pxx_Nf = signal.welch(data[nf_ts:nf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')
    Nf = Pxx_Nf

    """计算vf"""
    # vf_ts_list = [0,31,220,305,565] #拟合
    # vf_te_list = [10,47,235,320,580]

    vf_ts_list = [565,757,970,1003,1084] #预测
    vf_te_list = [580,780,990,1030,1131]

    Pvf_list = []
    vf_ts = vf_ts_list[0] * sample_frequency
    vf_te = vf_te_list[0] * sample_frequency
    f, Pxx_vf = signal.welch(data[vf_ts:vf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')
    Pvf_list.append(Pxx_vf)

    vf_ts = vf_ts_list[1] * sample_frequency
    vf_te = vf_te_list[1] * sample_frequency
    f, Pxx_vf = signal.welch(data[vf_ts:vf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')
    Pvf_list.append(Pxx_vf)

    vf_ts = vf_ts_list[2] * sample_frequency
    vf_te = vf_te_list[2] * sample_frequency
    f, Pxx_vf_1 = signal.welch(data[vf_ts:vf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')

    vf_ts = vf_ts_list[3] * sample_frequency
    vf_te = vf_te_list[3] * sample_frequency
    f, Pxx_vf_2 = signal.welch(data[vf_ts:vf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')
    Pvf_list.append(Pxx_vf_1+Pxx_vf_2)

    vf_ts = vf_ts_list[4] * sample_frequency
    vf_te = vf_te_list[4] * sample_frequency
    f, Pxx_vf = signal.welch(data[vf_ts:vf_te], sample_frequency, nperseg=200, noverlap=100, scaling='density')
    Pvf_list.append(Pxx_vf)

    return Nf,Pvf_list

"""手动选择文件"""
import tkinter as tk
from tkinter import filedialog
root = tk.Tk()
root.withdraw()
path = filedialog.askdirectory()  # 选择目录，返回目录名
all_filename = os.listdir(path)  # 保存目录下所有文件名
paths = []                       # 空列表，保存数据文件路径
for n in range(len(all_filename)):
    a = os.path.join(path,all_filename[n])
    paths.append(a)
all_source_name = []             #空列表，保存数据文件名（去后缀）
for n in range(len(all_filename)):
    filename = all_filename[n].split('.')[0]
    all_source_name.append(filename)
print(all_source_name)


"""将所有数据合并，计算E通道Nf、Pvf   SZ5  位置1"""
Nf_three = []
data_all = [np.full([1887502], np.nan),np.full([1887498], np.nan),np.full([1887532], np.nan)]
components = ['E', 'N', 'Z']
for i in range(0,1):
    label = 0
    direction = i # 选择输出通道方向
    data = data_all[direction]
    for n in range(direction,len(all_filename),3):
        st = obspy.read(paths[n])       # 读取N通道
        tr = st[0]
        """滤波"""
        tr_filt = tr.copy()
        # tr_filt.filter('bandpass', freqmin=1, freqmax=12, corners=2, zerophase=True)  # 带通滤波
        # tr_filt.filter('lowpass', freq=10.0, corners=2, zerophase=True)  # # 低通滤波
        tr_filt.filter('highpass', freq=1, corners=2, zerophase=True)  # 高通滤波
        signal_data = tr_filt.data

        """不滤波"""
        # signal_data = st.traces[0].data
        sample_frequency = tr.stats.sampling_rate       # 每秒记录 sample_frequency 个样本(采样频率)
        ts = 0        # 波形中开始的时间 秒（开始样本位置）
        te = tr.stats.npts           # 波形中结束的时间 秒（结束样本位置）
        signal_data = signal_data[ts:te]  # 对数据进行切片
        signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
        data[label:(label + len(signal_data))] = signal_data
        label += len(signal_data)
        if n == 9:
            label += 1510
        elif n == 10:
            label += 1494
        elif n == 11:
            label += 1283
        elif n == 24:
            label += 1280
        elif n == 25:
            label += 1487
        elif n == 26:
            label += 1412
        else:
            label = label

    """calculate"""
    sample_frequency = 200
    start_time_list = [[8129.72]]
    end_time_list = [[9329.72]]
    for j in range(0,1):
        start_time = start_time_list[i][j]
        end_time = end_time_list[i][j]
        ts = round(start_time * sample_frequency)  # 波形中开始的时间 秒（开始样本位置）
        te = round(end_time * sample_frequency)  # 波形中结束的时间 秒（结束样本位置）
        Nf,Pvf = inverse_calculate_nf_pvf(data, ts, te, sample_frequency)
        Nf_three.append(Nf)

N = pd.DataFrame(np.transpose(Nf_three), columns=['E_Nf'])
V = pd.DataFrame(np.transpose(Pvf), columns=['E_Pvf_30','E_Pvf_33','E_Pvf_36','E_Pvf_37'])
para_nf_vf = pd.concat([N,V],axis=1)

#para_nf_vf.to_csv(r'D:\PycharmProject\UndergraduateGraduation\paper_new\inverse\nf_vf_para_1_pre.csv', index=False)  # 保存文件

print('Finish')
