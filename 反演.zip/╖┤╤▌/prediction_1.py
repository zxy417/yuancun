import obspy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os.path
from scipy import signal
import datetime
import matplotlib.dates as mdates
from sklearn.linear_model import LinearRegression


def prediction_plot(para_pflow):
    t =  [datetime.datetime(2024, 3, 17, 17, 30)]
    for tm in range(10):
        T = t[tm] + datetime.timedelta(seconds=60)
        t.append(T)

    # t = np.arange(0,10)
    v = np.ones(11)*0.444
    fig1 = plt.figure(figsize=(10, 8))

    """预测数据与观测数据比对"""
    ax1 = fig1.add_subplot(1, 1, 1)
    ax1.plot(t, v, linestyle='solid', color='silver', label='Q$_o$$_b$$_s$')
    ax1.plot(t, para_pflow['E_pflow']/6.58E-05, linestyle='solid', color='k', label='Q$_p$$_r$$_e$')


    ax1.set_xlabel("Time", fontsize=18, fontproperties="Times New Roman")
    ax1.set_ylabel("Discharge (m$^3$/s)", fontsize=18, fontproperties="Times New Roman")
    ax1.set_xlim(t[0], t[9] + datetime.timedelta(seconds=60))
    ax1.set_ylim(0,1)
    ax1.tick_params(axis='both', tickdir='in')
    plt.xticks(fontsize=15, fontfamily='Times New Roman')
    plt.yticks(fontsize=15, fontfamily='Times New Roman')
    ax = plt.gca()
    timeFmt = mdates.DateFormatter('%H:%M')
    ax.xaxis.set_major_formatter(timeFmt)

    plt.legend(loc='upper right', fontsize=14, title_fontproperties='Times New Roman')


    plt.show()
   # fig1.savefig(r'C:\Users\小哲\Desktop\three_channel.tiff', dpi=300)

def pf_calculate(data,ts,te,sample_frequency,nf_vf):
    data = np.transpose(data[ts:te])  # 对数据进行切片并转置
    data = np.array(data).squeeze()

    Pf = []
    for k in range(0, len(data), 12000):
        f, Pxx = signal.welch(data[k:k + 12000], sample_frequency, nperseg=200, noverlap=100, scaling='density')
        if i == 0:
            Pft = Pxx - nf_vf['E_Nf']
            if k == 84000:
                Pft = Pft - nf_vf['E_Pvf']
            else:
                Pft = Pft
        elif i == 1:
            Pft = Pxx - nf_vf['N_Nf']
        else:
            Pft = Pxx - nf_vf['Z_Nf']
        Pf.append(Pft[4])

    return Pf
"""手动选择文件"""
import tkinter as tk
from tkinter import filedialog
root = tk.Tk()
root.withdraw()
path = filedialog.askdirectory()  # 选择目录，返回目录名
all_filename = os.listdir(path)  # 保存目录下所有文件名
paths = []                       # 空列表，保存数据文件路径
for n in range(len(all_filename)):
    a = os.path.join(path,all_filename[n])
    paths.append(a)
all_source_name = []             #空列表，保存数据文件名（去后缀）
for n in range(len(all_filename)):
    filename = all_filename[n].split('.')[0]
    all_source_name.append(filename)
print(all_source_name)


"""将所有数据合并，预测   SZ4  位置1"""
pf_three = []
df = pd.DataFrame()
data_all = [np.full([1863771], np.nan),np.full([1863708], np.nan),np.full([1863730], np.nan)]
components = ['E', 'N', 'Z']
for i in range(0,1):
    label = 0
    direction = i # 选择输出通道方向
    data = data_all[direction]
    for n in range(direction,len(all_filename),3):
        st = obspy.read(paths[n])       # 读取通道
        tr = st[0]
        """滤波"""
        tr_filt = tr.copy()
        # tr_filt.filter('bandpass', freqmin=1, freqmax=12, corners=2, zerophase=True)  # 带通滤波
        # tr_filt.filter('lowpass', freq=10.0, corners=2, zerophase=True)  # # 低通滤波
        tr_filt.filter('highpass', freq=1, corners=2, zerophase=True)  # 高通滤波
        signal_data = tr_filt.data

        """不滤波"""
        # signal_data = st.traces[0].data
        sample_frequency = tr.stats.sampling_rate       # 每秒记录 sample_frequency 个样本(采样频率)
        ts = 0        # 波形中开始的时间 秒（开始样本位置）
        te = tr.stats.npts           # 波形中结束的时间 秒（结束样本位置）
        signal_data = signal_data[ts:te]  # 对数据进行切片
        signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
        data[label:(label + len(signal_data))] = signal_data
        label += len(signal_data)
        if n == 9:
            label += 1320
        elif n == 10:
            label += 1393
        elif n == 11:
            label += 1415
        elif n == 15:
            label += 1411
        elif n == 16:
            label += 1369
        elif n == 17:
            label += 1493
        elif n == 24:
            label += 1354
        elif n == 25:
            label += 1447
        elif n == 26:
            label += 1324
        else:
            label = label
    """calculate"""
    nf_vf = pd.read_csv(r'D:\ZhouXiaoQi\biyederuanjian\小论文代码\代码\反演\nf_vf_para_1_pre1.csv')  # 导入数据
    start_time_list = [[8556.555]]
    end_time_list = [[9216.555]]
    for j in range(0,1):
        start_time = start_time_list[i][j]
        end_time = end_time_list[i][j]
        ts = round(start_time * sample_frequency)  # 波形中开始的时间 秒（开始样本位置）
        te = round(end_time * sample_frequency)  # 波形中结束的时间 秒（结束样本位置）
        # data = data[ts:te]  # 对数据进行切片
        # df[components[i]] = pd.DataFrame(data)
        pf = pf_calculate(data,ts,te,sample_frequency,nf_vf)
        pf_three.append(pf)
para_pflow = pd.DataFrame(np.transpose(pf_three), columns=['E_pflow'])




prediction_plot(para_pflow)