import obspy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os.path
from scipy import signal

def inverse_calculate(data,sample_frequency,nf_vf):
    data = data[~np.isnan(data)]  # 去除nan值
    f, Pxx = signal.welch(data, sample_frequency, nperseg=200, noverlap=100, scaling='density')
    Pf = Pxx

    if i == 0:
        af = (Pf - nf_vf['E_Nf'] - nf_vf['E_Pvf']) / 0.598
    elif i == 1:
        af = (Pf - nf_vf['N_Nf'] - nf_vf['N_Pvf']) / 0.598
    else:
        af = (Pf - nf_vf['Z_Nf'] - nf_vf['Z_Pvf']) / 0.598

    return af

def Sf(df,sample_frequency,para_af):
    sf_three = []
    Pf_model = pd.DataFrame(np.array(para_af * 0.598), columns=['E_Pf_model', 'N_Pf_model', 'Z_Pf_model'])
    for i in range(3):
        f, Pxx = signal.welch(data, sample_frequency, nperseg=200, noverlap=100, scaling='density')
        Pf_obs = Pxx
        if i == 0:
            sf = np.sqrt(((Pf_obs-Pf_model['E_Pf_model'])**2).sum()/100)
        elif i == 1:
            sf = np.sqrt(((Pf_obs-Pf_model['N_Pf_model'])**2).sum()/100)
        else:
            sf = np.sqrt(((Pf_obs-Pf_model['Z_Pf_model'])**2).sum()/100)
        sf_three.append(sf)

    return sf_three

def confidence_interval(para_sf,para_af):
    t = 1.660
    deta_three = []
    column1 = ['E_sf', 'N_sf', 'Z_sf']
    for i in range(3):
        deta = para_sf[column1[i]][0] / np.sqrt(101) * t
        deta_three.append(deta)

    return deta_three

"""手动选择文件"""
import tkinter as tk
from tkinter import filedialog
root = tk.Tk()
root.withdraw()
path = filedialog.askdirectory()  # 选择目录，返回目录名
all_filename = os.listdir(path)  # 保存目录下所有文件名
paths = []                       # 空列表，保存数据文件路径
for n in range(len(all_filename)):
    a = os.path.join(path,all_filename[n])
    paths.append(a)
all_source_name = []             #空列表，保存数据文件名（去后缀）
for n in range(len(all_filename)):
    filename = all_filename[n].split('.')[0]
    all_source_name.append(filename)
print(all_source_name)

"""将所有数据合并，计算三个通道Pf、af   SZ4  位置4"""
af_three = []
df = pd.DataFrame()
data_all = [np.full([1863771], np.nan),np.full([1863708], np.nan),np.full([1863730], np.nan)]
components = ['E', 'N', 'Z']
for i in range(0,3,1):
    label = 0
    direction = i # 选择输出通道方向
    data = data_all[direction]
    for n in range(direction,len(all_filename),3):
        st = obspy.read(paths[n])       # 读取N通道
        tr = st[0]
        """滤波"""
        tr_filt = tr.copy()
        # tr_filt.filter('bandpass', freqmin=1, freqmax=12, corners=2, zerophase=True)  # 带通滤波
        # tr_filt.filter('lowpass', freq=10.0, corners=2, zerophase=True)  # # 低通滤波
        tr_filt.filter('highpass', freq=1, corners=2, zerophase=True)  # 高通滤波
        signal_data = tr_filt.data

        """不滤波"""
        # signal_data = st.traces[0].data
        sample_frequency = tr.stats.sampling_rate       # 每秒记录 sample_frequency 个样本(采样频率)
        ts = 0        # 波形中开始的时间 秒（开始样本位置）
        te = tr.stats.npts           # 波形中结束的时间 秒（结束样本位置）
        signal_data = signal_data[ts:te]  # 对数据进行切片
        signal_data = (((signal_data * 1.19209289550781E-07) / 80) * 1000)  # 电信号转为速度信号  # 转存微震时间序列 m/s
        data[label:(label + len(signal_data))] = signal_data
        label += len(signal_data)
        if n == 9:
            label += 1320
        elif n == 10:
            label += 1393
        elif n == 11:
            label += 1415
        elif n == 15:
            label += 1411
        elif n == 16:
            label += 1369
        elif n == 17:
            label += 1493
        elif n == 24:
            label += 1354
        elif n == 25:
            label += 1447
        elif n == 26:
            label += 1324
        else:
            label = label
    """calculate"""
    nf_vf = pd.read_csv(r'D:\ZhouXiaoQi\biyederuanjian\小论文代码\代码\反演\nf_vf_para_4.csv')  # 导入数据
    start_time_list = [[4870.83], [4872.96], [4872.56]]
    end_time_list = [[5470.83], [5472.96], [5472.56]]
    for j in range(0,1):
        start_time = start_time_list[i][j]
        end_time = end_time_list[i][j]
        ts = round(start_time * sample_frequency)  # 波形中开始的时间 秒（开始样本位置）
        te = round(end_time * sample_frequency)  # 波形中结束的时间 秒（结束样本位置）
        data = np.transpose(data[ts:te])  # 对数据进行切片并转置
        data = np.array(data).squeeze()
        df[components[i]] = pd.DataFrame(data)
        af = inverse_calculate(data,sample_frequency,nf_vf)
        af_three.append(af)

para_af = pd.DataFrame(np.transpose(af_three), columns=['E_af','N_af','Z_af'])
sf = Sf(df,sample_frequency,para_af)
para_sf = pd.DataFrame([sf], columns=['E_sf','N_sf','Z_sf'])
deta = confidence_interval(para_sf,para_af)
para_deta = pd.DataFrame([deta], columns=['E_deta','N_deta','Z_deta'])

"""plot"""
para_af_E_lower = (np.array(para_af['E_af'])-np.ones(101)*para_deta['E_deta'][0]).squeeze()
para_af_E_upper = (np.array(para_af['E_af'])+np.ones(101)*para_deta['E_deta'][0]).squeeze()

para_af_N_lower = (np.array(para_af['N_af'])-np.ones(101)*para_deta['N_deta'][0]).squeeze()
para_af_N_upper = (np.array(para_af['N_af'])+np.ones(101)*para_deta['N_deta'][0]).squeeze()

para_af_Z_lower = (np.array(para_af['Z_af'])-np.ones(101)*para_deta['Z_deta'][0]).squeeze()
para_af_Z_upper = (np.array(para_af['Z_af'])+np.ones(101)*para_deta['Z_deta'][0]).squeeze()


frequency = np.arange(0,101)
fig1 = plt.figure(figsize=(10, 8))  # 绘制波形图(三通道)
ax1 = fig1.add_subplot(1, 1, 1)
ax1.plot(para_af['E_af'],frequency,linewidth=0.9,linestyle='solid',color='#87CEFA',label='E')
ax1.fill_betweenx(frequency,para_af_E_lower,para_af_E_upper,facecolor='r',alpha=0.2,label='componet E 95%confidence interval')

ax1.plot(para_af['N_af'],frequency,linewidth=0.9,linestyle='dashed',color='#87CEFA',label='N')
ax1.fill_betweenx(frequency,para_af_N_lower,para_af_N_upper,facecolor='y',alpha=0.2,label='componet N 95%confidence interval')

ax1.plot(para_af['Z_af'],frequency,linewidth=1,linestyle='dashdot',color='#87CEFA',label='Z')
ax1.fill_betweenx(frequency,para_af_Z_lower,para_af_Z_upper,facecolor='#ADD8E6',alpha=0.4,label='componet Z 95%confidence interval')

ax1.set_ylabel("Frequency (Hz)", fontsize=17,fontproperties="Times New Roman")
ax1.set_xlabel(r"a$_f$  [$\frac{(m/s)^2/Hz}{m^3/s}$]", fontsize=17,fontproperties="Times New Roman")
ax1.xaxis.get_major_formatter().set_powerlimits((0, 1))
ax1.tick_params(axis='both', tickdir='in')
plt.xticks(fontsize=14, fontfamily='Times New Roman')
plt.yticks(fontsize=14, fontfamily='Times New Roman')
plt.xlim(0, para_af['E_af'].max())
plt.ylim(0, 100)





plt.legend(loc = 'upper right',fontsize=12,title_fontproperties='Times New Roman')
plt.show()
#fig1.savefig(r'C:\Users\小哲\Desktop\three_channel.tiff', dpi=300)
print('Finish')
